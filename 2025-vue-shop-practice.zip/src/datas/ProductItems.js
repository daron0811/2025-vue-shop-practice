export const productDatas =
    [
        {
            id: 0,
            name: "耳罩式藍牙耳機",
            description: "舒適配戴，支援降噪技術",
            price: 2490,
            img: "https://images.unsplash.com/photo-1546435770-a3e426bf472b?q=80&amp;w=2065&amp;auto=format&amp;fit=crop&amp;ixlib=rb-4.1.0&amp;ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        },
        {
            id: 1,
            name: "智障型手機",
            description: "輕巧方便，超大音量，全新無按鈕設計。",
            price: 5000,
            img: "https://images.unsplash.com/photo-1499159058454-75067059248a?q=80&w=1171&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
        }
        ,
        {
            id: 2,
            name: "電競鍵盤 (跪)",
            description: "下班就回家的老公，不會用到",
            price: 777,
            img: "/keyboard.jpg"
        },
        {
            id: 3,
            name: "貓型 AI 智慧機器人",
            description: "22 世紀最新科技，搭載最新 AI 演算技術，擬真語音行為，智慧助理首選",
            price: 99999,
            img: "/bot.jpg"
        },
        {
            id: 4,
            name: "老鼠造型 無線滑鼠",
            description: "貓型機器人最害怕的 3C 產品。到底是什麼原因，目前還是個謎...",
            price: 299,
            img: "/mouse.jpg"
        }
    ];
